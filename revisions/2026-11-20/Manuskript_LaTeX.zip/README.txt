Compile Manuskript.tex with pdfLaTeX until references and page counts are stable (or use latexmk -pdf).
The bibliography is embedded; no BibTeX run is required.
