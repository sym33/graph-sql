# Evidence accompanying the compact Supplement

INDEX.csv maps sections S1–S11 to full detailed documents and the six unchanged original archives. The human-readable supplement is supplied separately as Supplement.pdf. The old detailed PDFs are retained here as records; they are not additional required reading or separate current supplements. S5, S6, S7 and S9 originally describe code/evidence packages rather than separate PDF documents.

Extract an archive before running its verification script. Reviewer_Controls.zip supplies code/verify_controls.py (pass its results directory); Followup_Controls.zip supplies code/verify_followup.py. These verify saved results without starting database services. Their README files document dependencies. Native remeasurement requires the original frozen reproduction base, specified software and adaptation of dedicated paths; recorded paths are historical, not current installation instructions.

The base reproduction package is identified by the DOI/source revision in the manuscript and is separately retained locally under Archiv/. It is not duplicated in this small evidence archive. Full retrieved product-information PDFs are not included. Third-party sources retain their provider rights.

All six component archives and fourteen detailed document files preserve the pre-compaction bytes. No new experiments were performed. The withdrawn extension series and S12 are excluded.
