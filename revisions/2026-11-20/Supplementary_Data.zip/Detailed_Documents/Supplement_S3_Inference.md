# Supplement S3. Inference rules and verification

## Meaning of the inferred relationships

A documentary candidate connects a Swiss product classification to a frozen tariff record with the same ATC code. Historical classifications and European medicine references retain separate scopes. Recorded ingredient declarations retain source-row identity, including combination descriptions.

The local ontology evaluates four property chains:

1. Recorded classification followed by tariff listing derives a documentary tariff connection.
2. Historical classification followed by tariff listing derives a historical review connection.
3. Recorded classification followed by dictionary-supported hierarchy derives a broader group.
4. A source-row ingredient declaration inherits its witness’s documentary tariff connection.

These rules compose recorded relationships. Their meaning follows from source identity, linking conditions and the requested target; the ontology supplies an executable representation.

## Admission and independent comparison

Admission authenticates classification fields, exact premises and product endpoints. Documentary candidates require Swiss jurisdiction, a direct or authorization-linked SL classification, exact tariff-code equality and the requested frozen tariff version. Historical witnesses are evaluated under a separate target. European-only paths remain unavailable for the Swiss target without an identity bridge. Independent SQL reconstructs every expected candidate and declaration pair from source records. OWL-RL materialization and native Cypher are compared with these outputs. SHACL checks types, premises, snapshots and historical/documentary separation. Removing one chain tests whether its outputs depend on the intended rule and whether unrelated outputs remain unchanged.

## Complete results and controlled challenges

The D0 population contains 1,559 documentary derivations, 564 unique product–tariff candidates, 468 Swiss authorizations and 179 tariff records. Four candidates depend on the alternative SL classification. Five historical derivations concern two otherwise unconnected Swiss products; 324 European-reference paths remain outside the Swiss population. Additional outputs comprise 5,204 broader-group derivations and 999 tariff pairs for 837 ingredient declarations.

Nine challenges per documentary derivation produce 14,031 cases. Faithful controls are verified; available-context field conflicts are contradicted. Missing sources, incorrect endpoints, unavailable snapshots or tariff versions, unsupported payment targets and altered tariff payloads are undetermined. All five historical paths and 324 European paths remain undetermined when improperly promoted to Swiss documentary candidates. Five structural fixtures check missing premises, wrong types, missing snapshots and historical leakage. All complete outputs agree across the applicable SQL, OWL and native graph comparisons.

## Relation to the database comparison

The Neo4j model stores classification and source-premise relationships; normalized SQLite tables retain the same records and linking facts. Query-time variants compute tariff reachability by code equality. Stored variants retain each witness–tariff connection as a graph relationship or indexed relational row, preserving its explanation. Separate declaration follow-up demonstrates downstream use of inferred relationships. OWL-RL reasoning and SHACL validation run through the supplied RDF adapter. Cypher authenticates physical graph paths and materializes their derived relationships in Neo4j; the semantic checks remain separate from the choice of database engine. Construction and invalidation are timed separately from retrieval in the source-refresh experiment. Executable rules and source traces are included in the experiment package.
