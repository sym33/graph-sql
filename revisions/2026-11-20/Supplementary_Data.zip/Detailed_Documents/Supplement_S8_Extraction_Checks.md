# Supplement S8. Ancillary LLM extraction checks

Language models assisted documentary retrieval, extraction and source comparison. These checks are ancillary; they do not define the candidate population, database timing results or a human expert reference standard. Official keyed comparisons remain distinct from model outputs.

## Context-separated readings

Two isolated general-purpose LLM contexts assessed 101 comparisons using 65 distinct Swiss professional-information documents per reader, with algorithm labels withheld. A third context examined disagreements before unblinding. Current route-overlap directions agreed in all 101 cases; conservative presentation identity remained unresolved in five. Historical D0 applicability was not established. The interface exposed neither a versioned model identifier nor sampling parameters. Shared model and document origins limit independence; protocols, source locators and locked readings are retained in S6.

## Model-family sensitivity

Llama 3.3 70B followed by Qwen 2.5 32B, both Q4_K_M via Ollama, received identical tariff-blinded excerpts in 67 requests per model. Settings were temperature 0, seed 20261026, top-p 1, context 24,576 and output limit 4,096 tokens. Outputs were locked before tariff-overlap analysis.

Structured responses covered 98 Llama and 99 Qwen cases; current routes agreed in 92 of 96 paired cases. Differences involved two Entyvio presentations, Voriconazol-Mepha and Luxturna. Mechanical citation checks failed in 64/98 and 13/99 cases, respectively. Three truncated outputs accounted for five missing case records. Citation-line availability does not establish entailment, and identity/historical fields were unreliable. Agreement therefore supplies sensitivity evidence rather than accuracy. S7 retains weight digests, native responses, hashes and replay code; exact output regeneration is not guaranteed.
