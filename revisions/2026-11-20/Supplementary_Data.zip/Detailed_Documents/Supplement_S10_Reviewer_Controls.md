# Supplement S10 Reviewer requested execution controls

This supplement retains the initial control session. The subsequent randomized common-budget comparison and separated aggregation analysis are in Supplement S11.

These exploratory controls were specified before their new measurements on 20 November 2026. They use the unchanged frozen D0/D1 sources and independent complete-answer reference. They are separate from the historical measurements used by the serial-cost model in Supplement S9.

## Design and environment

The new runs use Linux-6.8.0-117-generic-x86_64-with-glibc2.39, Python 3.12.3, SQLite 3.45.1 and Neo4j Community 5.26.1 on the same research host as the historical experiments. The full CPU, RAM, kernel, Java, CPU-affinity and initial load records are in results/environment.json. A dedicated loopback Neo4j instance uses HTTP 19674, a 1 GiB initial/2 GiB maximum heap and 1 GiB page cache. Existing research stores were not modified. Source-file checksums were checked before execution; exact query strings, schema and plans are retained. The separate audited_plans.json reconstructs D1 after timing and rechecks fourteen complete Neo4j answers; it contains estimated EXPLAIN plans rather than per-sample runtime profiles. The original post-run plans are also retained.

SQLite memory arms retain the same indexed 74,301,440-byte file, fixed join order, predicates and answer content. Each memory arm runs in a separate Python process. The default settings read back cache_size=-2000 and mmap_size=0; the enlarged arms use cache_size=-1048576, with mmap_size either zero or 1073741824. Page size is 4096 bytes. These are capacity allowances, not allocated total footprints. Journal mode is DELETE, synchronous is 2 and temp_store is 0 in the read-back controls. No global operating-system cache eviction is performed.

Three blocks randomize the SQLite memory-arm sequence. Each task/derivation condition receives three warmups and fifteen timed repetitions per block, giving 45 samples per condition. Neo4j is measured in a separate sequence after SQLite in each block. The two tasks retrieve combined source context and tariff peers with indication evidence; each returns all requested fields and multiplicities. Timing includes local HTTP request, complete transfer and decoding. Sorting, hashing and oracle comparison occur outside the interval. These sequences do not constitute a fully randomized paired engine comparison. Shared-host load and fixed sequence can influence differences.

## Cache capacity and retrieval

Table 1. New warm-cache retrieval medians [Q1–Q3] in milliseconds. QT is query-time derivation and S is stored derivation. Each cell contains 45 repeated measurements across three blocks; repetitions are not independent deployments.

| Configuration | Strategy | Combined context | Tariff peers and indication |
| --- | --- | --- | --- |
| SQLite default | QT | 36.84 [35.39–37.91] | 128.38 [126.56–129.80] |
| SQLite default | S | 40.19 [39.07–41.45] | 169.85 [167.80–171.80] |
| SQLite 1 GiB cache | QT | 31.99 [30.98–32.91] | 117.68 [116.85–120.18] |
| SQLite 1 GiB cache | S | 34.52 [33.10–36.48] | 150.42 [148.40–151.81] |
| SQLite 1 GiB cache and mmap | QT | 31.12 [29.92–46.84] | 117.15 [115.48–208.45] |
| SQLite 1 GiB cache and mmap | S | 33.61 [31.91–50.55] | 145.21 [143.19–259.70] |
| Neo4j 1–2 GiB heap and 1 GiB cache | QT | 161.89 [157.43–272.38] | 1157.36 [1123.15–1376.56] |
| Neo4j 1–2 GiB heap and 1 GiB cache | S | 45.95 [41.04–60.79] | 489.43 [362.99–662.27] |

All 720 timed responses equal the independently reconstructed complete reference answers. Every context response has 1,018 rows and every tariff-peer response 478 rows. Enlarging permitted memory is not equivalent to changing query plans, protocol costs or source information. The observed capacities therefore cannot establish a universal direction or magnitude for an engine gap.

Table 2. SQLite worker process RSS range across the three blocks, in MiB, measured after retrieval. Python, expected answers and allocator retention from reference reconstruction are included; these are not engine-only footprints.

| SQLite capacity arm | RSS range MiB | High water mark range MiB |
| --- | --- | --- |
| default | 154.5–156.3 | 170.0–170.4 |
| cache 1GiB | 173.3–174.9 | 191.2–192.8 |
| cache 1GiB mmap 1GiB | 200.8–200.9 | 218.3–218.6 |

The Neo4j process RSS after the complete control run is 2795.4 MiB. This single post-run reading includes the JVM and follows a different execution history, so it is not an engine-memory ratio or a matched-resource experiment.

## Directly timed lifecycle and projection calibration

Seven repetitions randomize the four engine/derivation arms. Each run begins from an empty layer with existing schema/index definitions, builds D0, optionally materializes links, invalidates stored links, replaces the source layer by D1, optionally reconstructs stored links, and issues 100 combined-context requests. SQLite uses a fresh file and runs ANALYZE after replacement. The outer timer includes loading, commits, upkeep, ANALYZE and HTTP consumption; reference construction, schema creation, service start and answer validation are excluded. All seven complete D1 query outputs are checked after every run. Native loading paths remain local SQLite inserts versus batched Neo4j HTTP, so totals remain configuration/deployment measurements.

Table 3. Directly measured total medians [Q1–Q3] in seconds over seven repetitions. The adjacent projection is calculated only from these same new runs: sum of phase medians plus 100 times pooled retrieval median. Its relative difference is (projection / measured median − 1) × 100.

| Engine | Strategy | Observed total seconds | Same-run phase projection seconds | Difference percent |
| --- | --- | --- | --- | --- |
| Neo4j | QT | 37.80 [35.02–38.24] | 32.89 | -13.01 |
| Neo4j | S | 32.50 [20.98–37.10] | 29.97 | -7.79 |
| SQLite | QT | 6.80 [6.46–7.31] | 7.10 | +4.31 |
| SQLite | S | 6.19 [5.29–7.74] | 5.42 | -12.46 |

The deviations reach 13.01% underestimation and 4.31% overestimation in this session. S11 decomposes this difference and shows that pooled single-request extrapolation, rather than individual-phase-median aggregation, dominates the largest error. This is material relative to small projected advantages near a crossover: summing component medians cannot be treated as measuring the total, and component-wise bounds do not capture every model-form or session effect. These 28 direct totals check a single defined workload horizon. They do not turn the original component medians into observed totals, validate all 600 scenario mixtures, establish cold-cache behavior or predict concurrent service throughput. The new runs include their own environment and timing boundaries and do not replace historical model inputs. Quartiles use Python statistics.quantiles with its default exclusive convention; medians, samples and boundaries are retained for independent recalculation.

## Reproduction and source bound cases

The accompanying Reviewer_Controls.zip contains PROTOCOL.json, source checksum expectations, the executed run_controls.py, raw results, query plans, execution log, verification/report scripts and the independently reconstructed selected_cases.json. Run verify_controls.py on the saved results directory to check counts, complete-answer hashes, medians and lifecycle timer coverage. This verification does not rerun a database. Native rerunning requires the frozen sources and original comparison/reference modules from the base package and a dedicated Neo4j installation; directory setup in the recorded script explicitly identifies the original research installation. All endpoints are loopback-only. The source-bound worked cases are described in Supplement S4.
