# Supplement S1. Evaluation design and checks

D0 is the reference dataset and D1 the SL/Refdata replacement dataset defined in Materials and Methods. A separate comparison extract supports the secondary classification and controlled-case checks; it is distinct from D1. Frozen file identities are retained in the reproduction manifest.

## Evaluation design

The reusable evaluation separates the answer specification from its implementation. Entity keys, requested fields, supporting records, interpretation status and multiplicity define the answer specification. A separate implementation reconstructs these outputs from frozen sources. Physical graph and relational extracts must agree on complete outputs, including after source replacement. The present checks apply this procedure to classification derivations, indication assertions and medication–tariff questions. Record identities, endpoints and source payloads are checked alongside conclusions, so equality of counts alone cannot satisfy the comparison.

Thirteen controlled operations apply to every selected classification and indication unit. They cover faithful attribution, altered subject or fields, incorrect derivation or jurisdiction, unsupported wider claims, unavailable time or snapshot, missing certificates, coherent payload changes and wrong product endpoints. Classification uses one witness per distinct product–ATC pair: 8,155 comparison extract and 8,163 D0 units. Indication uses every witness: 17,428 and 17,447 units. All 665,509 single-defect cases agree with their specified outcomes. Each operation tests a specified property; cases reuse source records and measure coverage of that specification.

## Source-attribution and context constraints

The assessment checks evidence identity, exact source attribution, product and premise binding, applicable context, informative content and field agreement. The omission comparison removes one requirement at a time. False confirmations measure acceptance of constructed cases that the full specification rejects.

| Omitted obligation | Comparison-extract false confirmations | D0 false confirmations |
| --- | --- | --- |
| None | 0 | 0 |
| Frozen-source binding | 17,428 | 17,447 |
| Physical endpoints | 17,428 | 17,447 |
| Asserted fields | 69,712 | 69,788 |
| Snapshot and scope | 87,140 | 87,235 |

Mixed-failure cases test decision order: unavailable context leaves the requested claim undetermined while retaining authenticated frozen-field conflicts. Malformed premises remain undetermined rather than causing exceptions. Five metamorphic operations over 18,339 comparison extract witnesses provide 91,695 checks of representation and order invariance. The finite specification also exhausts all 64 combinations of its six Boolean obligations.

SHACL comparisons cover 1,040 stratified cases and 480 mixed-failure classification cases. The constraints check source equality, premises, endpoints, snapshot and claim scope. Imperative, declarative and independently expressed SQL decisions agree. Seven route-certificate mutation families test altered status, target, route fields, premises, snapshot, policy and witness: all 20,979 modified certificates are rejected, as are 63 stratified mutants evaluated directly through pySHACL.

## Analytical agreement and dataset scope

Complete graph and relational checks cover candidate discovery, classification-source views, route judgments and weighted MeSH pairs. The 104,682 D0 context decisions agree; all 18,509 content-eligible MeSH pair-and-term outputs agree. Original source records and relationships are preserved when assessments or temporary inferred links are added and removed.


## Boundary between computational and professional validation

Agreement, mutation and certificate results assess the declared documentary specifications. Separate implementations can share a mistaken domain premise; computational consistency therefore does not establish clinical appropriateness or payment entitlement. Official-reference comparisons assess the sampled product and pack keys independently of ATC matching, while selected Swiss–EU documents assess presentation-specific routes (Supplement S7). The sample excludes candidates without package evidence and does not estimate population accuracy.

The primary route analyses use coarse and exact-code comparisons. The formulation-token field is an ancillary lexical assessment. Candidate-profile and ATC-edit analyses quantify aggregation and source-curation sensitivity (Supplements S4–S5). The workload census reconciles peer memberships and fixed-anchor explanation rows with measured outputs without extending the timing sample.

## Documentary assessment and catalogue scope

Official identifier/classification concordance and selected Swiss–EU route comparisons are documented in S7. Ancillary extraction checks, their technical assistance and validity limits are summarized in S8.

The frozen tariff table is a base-definition projection that pools SwissDRG ZE, TARPSY TZE and ST Reha RZE. D0 has 535/26/3 candidates in these scopes; D1 has 545/27/3. The 185 input definitions comprise 182/2/1, retaining V15.3/T6.3/R3.3. All 182 ZE signatures match official November 2025 and April 2026 source fields, and separate official TARPSY/ST Reha documents corroborate the other three routes. The official November 2025 EDV documentation explicitly refers the va field to the 2023 technical companion, Section 3.1.c. Dose-band and product-specific billing conditions remain outside the route comparison. Complete source URLs, checksums, scope tables and analysis are in S6.
