# Supplement S4. Interpretation rules and implementation comparisons

D0 and D1 denote the source states in Materials and Methods. Coarse and exact-route comparison are the primary route analyses. The formulation-token filter is an ancillary lexical availability assessment used in the evidence-request categories. Its selected word list is not a clinically validated formulation classifier. Exact source identities are recorded in the reproduction manifest.

## Interpretation rules and source checks

The following sections specify interpretation rules and source checks, report execution costs and characterize exploratory analyses and configuration selection. Optional information acquisition is treated separately. Citation numbers refer to the manuscript.

Table 1. Semantic warrants for the decisive application rules.

| Rule and target | Warrant and licensed inference | Unavailable condition and counterexample |
| --- | --- | --- |
| Literal source attribution | Frozen bytes, record digest, original field; PROV-DM (main reference 22). Only the exact named record supports its attribution | Missing record or digest disagreement. Curated code agrees with WHO but differs from raw Refdata |
| Requested time/authority scope | Claim definition and source-specific date/authority fields. Field disagreement refutes only an applicable proposition | Effective date, authority or snapshot unavailable. Frozen conflict with unsupported current-time request |
| Swiss product linkage | Exact authorization field in SAI and SL source records. Equal scoped identifiers support a documentary join | No Swiss identity bridge or incompatible entity level. European ingredient record with no Swiss authorization bridge |
| Historical classification target | Retained WHO alterations (main reference 63) with old/new code relation. Historical support is assessed separately from direct recording | No recorded alteration connecting the codes. Historical code must not become a direct current recording |
| Broader classification target | Retained ATC dictionary and declared prefix hierarchy. Ancestor relation supports only the broader-group proposition | Code not supported by retained dictionary. Same broad class does not establish exact code equality |
| Information-bearing coannotation | Source missingness marker and lexical term field. Missingness is not an informative shared term | Missing marker or absent term. Fourteen missing annotations induce 91 false content pairs |
| Documentary catalogue candidate | Source ATC equals frozen tariff ATC. Supports recorded classification-to-catalogue association | No exact code, unsupported jurisdiction or missing version. Code candidate does not establish payment entitlement |
| Recorded route-family compatibility | Technical companion group glossary; tariff va field (main reference 50). Overlap at oral/parenteral resolution | Absent family or unmapped nonoverlapping route. SC and IV share a family but differ at exact resolution |
| Recorded route-code compatibility | IV/SC/IM/IT or subkutan recorded in the medicine’s package description; explicit oral group. Overlap of explicitly represented route codes | Generic Parenteral alone has no exact code. Infusion description alone cannot supply IV |
| Ancillary formulation-token availability | Same-record tablet/capsule or infusion/injection/powder tokens. Establishes only whether these selected strings accompany an exact route | Missing tokens leave the lexical audit unavailable; this is not evidence against the dosage form or the exact route |
| Existence of a package record documenting a compatible medicine route | All package-record route assessments for the same product–tariff key. Any V establishes route support; all C establishes a conflict-only view | No packages or mixed C/U. One compatible route assessment does not establish compatibility for every medicinal presentation |
| Selected formulation documentary interpretation | EMA PDF identity; section 1 and 4.2 in one complete SmPC block (main references 51–58). Selected administration text supports that selected formulation | Ambiguous title, absent section or boundary. Capsule route text must not support an infusion title |
| External classification compatibility | ChEMBL identity policies, retained source IDs and ATC fields (main reference 46). Supports the specified reference entity comparison | Identity unavailable or reference lacks relevant ATC. Ingredient-level match cannot adjudicate Swiss product authorization |

The coarse policy reads terminal oral/parenteral group tokens and projects O to oral and IV/SC/IM/IT to parenteral. The exact policy recognizes explicitly recorded O, IV, SC, IM and IT, including subkutan as SC; generic Parenteral leaves exact specificity unavailable. Word boundaries prevent misleading partial matches. The formulation policy additionally requires tablet/capsule or infusion/injection/powder wording in the same package record. Formulation wording alone cannot establish an absent exact route.

Overlap supplies compatibility. Without overlap, missing specificity or uninterpreted options yield UNDETERMINED; fully interpreted disjoint values yield CONTRADICTED. Any package record documenting a compatible medicine route establishes product-pair route support; conflict-only requires a conflict from every linked package-record assessment. The 137 candidates without SL packages remain undetermined under every policy.

Of 913 coarse-compatible paths, exact assessment retains 292, leaves 615 undetermined and identifies six conflicts. Of 84 coarse conflicts, 78 persist and six become undetermined. The six newly exposed SC–IV conflicts concern Entyvio pen/syringe, Ocrevus SC, Rybrevant SC and Darzalex SC. Sixty-four paths remain conflicting under all three policies. These are source-path findings over a dependent package population. At candidate level, the 388 coarse positives split into 92 positives under both finer criteria, five conflicts under both, 281 undetermined under both and ten exact positives that become formulation-undetermined. These four groups are disjoint and exhaustive.

For completion, known oral/parenteral families also exclude impossible exact routes. This supplies seven additional conflict-only product-pair judgments while preserving all previously determinate judgments. The remaining 419 unresolved pairs comprise 137 missing package links, 281 missing exact routes and one unmapped family. Of 495 missing-route records, 97 have positive guaranteed clarification gain; the largest guaranteed single-field gain is two.

The review-request export selects one category using prerequisite order: obtain the linked package, inspect a recorded finer-policy conflict, obtain the exact route, then obtain formulation wording. A recorded conflict takes priority over additional missing fields; exact-route evidence is a prerequisite of the formulation-qualified policy. The full judgments and source records are retained alongside this next request. The D0 counts are 137 requests for package linkage, 289 for explicit routes, ten for formulation evidence, 36 conflict reviews and 92 supported contexts. D1 counts are 138, 298, ten, 36 and 93. Judgment changes affect ten shared candidates and twelve policy-specific judgments; review-category changes affect twelve shared candidates. These are different units.

The CSV retains authorization, tariff, three judgments, review category and package-record identities. The JSON supplies before/after records for 31 alerts: fifteen additions, four removals and twelve changed shared review categories. Two category changes leave all judgments unchanged. Independent reconstruction reconciles the complete candidate and judgment changes with the executed comparison.

The retrospective monitoring ablation retains both source populations, all interpretation rules and the same product–tariff keys. Membership-only monitoring admits the 15 additions and four removals. Judgment-aware monitoring also admits a shared key when any of its three policy statuses changes. Request-aware monitoring additionally admits a shared key when its deterministic review-request category changes. The nested sets contain 19, 29 and 31 keys, respectively; their increments are 19, ten and two, and their omissions relative to the full workflow are twelve, two and zero. Ten shared keys change both judgments and requests; two change requests alone. The union population is 579 keys. These are exact counts under the declared rules, not estimates of clinical relevance or operational detection sensitivity.

### Source perturbations, review priority and cached answers

The perturbation analysis covers all contributing package records: 837 in D0 and 853 in D1. Scenarios retain source-record coordinates while varying fields to isolate dependency effects; per-trial digests identify the hypothetical answers. Each of the 1,690 record–dataset combinations receives six single-record perturbations: missing or unmatched authorization, missing or unmatched classification, reassignment to a different existing authorization, and masked route fields. The reassignment target is the lexicographically first different authorization in that state’s candidate population; this is a fixed stress control, not a sampling estimate. Source values are restored between trials. Adjacency traversal and SQL joins agree on all 10,140 perturbed answers. They construct the source paths separately and use the same route-interpretation and aggregation functions. Reconstructed unmodified answers also agree with the existing candidate, judgment and review-request census.

The five loss/missingness conditions produce 8,450 trials and introduce no candidate keys. Guarded admission excludes missing authorization identifiers. A paired co-missing-key control in each dataset shows why this matters: unrestricted equality creates one candidate from two blank keys, while the presence guard admits none. Valid-shaped reassignment adds candidates in 835 of 837 D0 trials and 851 of 853 D1 trials, producing 2,013 added-candidate occurrences across separate reset trials. These occurrences reuse source records and are not distinct clinical errors. They demonstrate that equality of a valid identifier does not independently establish its correctness.

Table 2. Sensitivity of review requests to priority. Package linkage is first in every ordering. The counts compare selected requests with the default ordering; all six identify the same twelve shared update-alert keys. Only orders with route before formulation preserve that prerequisite.

| Priority after package linkage | D0 requests changed | D1 requests changed | Route before formulation |
| --- | --- | --- | --- |
| Conflict → route → formulation (default) | 0 | 0 | Yes |
| Conflict → formulation → route | 289 | 298 | No |
| Route → conflict → formulation | 0 | 0 | Yes |
| Route → formulation → conflict | 11 | 11 | Yes |
| Formulation → conflict → route | 300 | 309 | No |
| Formulation → route → conflict | 300 | 309 | No |

Among the three prerequisite-respecting orders, swapping conflict and missing exact route leaves every request unchanged. Deferring conflict until after missing formulation changes eleven requests in each dataset. Changing priority leaves judgments and premises intact and changes which issue is presented next. Table 2 distinguishes this action choice from the stable set of update alerts.

Four update operations are applied to each contributing package: deletion, unmatched classification, route masking, and insertion of an identical-content record with a new source identity. Across 6,760 cases, reusing the unmodified graph-reference answer is distinguishable from the SQL reconstruction every time. Rebuilding the affected authorization’s answer restores exact equality and is idempotent; restoring the original record recovers its original answer. Candidate keys remain unchanged in all four cache-update families. Route masking produces 475 judgment-change and 230 review-request-change occurrences; deletion and code removal each produce 333 judgment-change and 338 request-change occurrences. Duplicate insertion changes source multiplicity and premises while retaining judgments and requests. Counts describe dependent documentary trials, not clinical accuracy or independent observations.

These are offline cache checks against SQLite, using the fixed source rules. The seven native Neo4j/SQLite replacement cycles remain the evidence for full database refresh.

### Authenticating judgments and checking external documents

Certificates retain the candidate, policy, snapshot, compared source fields and exact premises. Complete reconstruction checks their source binding and recomputes the decision. All 2,997 three-policy certificates conform; all 20,979 certificates altered across seven mutation families are rejected. Direct pySHACL execution rejects 63 stratified mutants. Supplement S1 gives the wider validation design.

Eight selected official EMA documents supply 16 complete formulation blocks: fourteen have an explicit positive route and two remain unavailable under the extraction rules. The administration text must belong to the same complete formulation block as its title. Twenty-two assertion controls and four boundary controls test positive statements, negation, conditions, opposing assertions and misplaced evidence. Qualified prohibitions of IV push/bolus remain administration-mode restrictions. The seven observed tariff tokens have explicit correspondences in the published EDQM vocabulary (main reference 59).

### Reusing inferred relationships

Declaration groups retain literal source descriptions, including combinations. Every inferred declaration–tariff pair enters the analysis; a mixed group contains package records yielding at least one compatible and one conflicting medicine-route assessment. The exact-code policy is primary, with coarse and formulation policies as sensitivities. Exact and formulation policies retain two mixed groups, both voriconazolum. Their exact-route profiles are 12/1/4 and 1/12/4 (compatible/conflicting/undetermined); formulation profiles are 8/1/8 and 1/8/8. The five complete Vfend label fields provide independent EU formulation context; their titles, pages and route text are retained in the experiment package.

The L04AC07 cohort comprises all five medicines with that recorded classification. Complete packaging label section 5 fields supply route inventories, bound to the preceding product title. All five SmPC ATC fields agree with cohort membership. The 22 retained label fields produce eight source medicine–route relationships and 32 directed comparisons. Exact inventories support 24 comparisons and identify eight noncoverage results: four target STADA for SC and four target Tuyory for IV. Each result concerns documentary inventory membership. Native graph and independent relational implementations reproduce these comparison keys and decisions. Removing derived relationships empties the downstream query and restoration reproduces it; original source records remain unchanged.

## Execution and lifecycle costs

The five primary retrieval tasks return 1,589 tariff-witness rows, 2,607 source-lineage rows, 2,607 rule-context rows, 1,018 combined-context rows and 478 peer rows for D1. The execution-plan control retains the same 1,018 combined-context and 478 peer rows. Each count includes the complete output multiplicity required by that task.

Table 3. Four-variant retrieval distributions, median [Q1–Q3] milliseconds. Values use D1 and automatic SQLite plans.

| Task | SQLite query-time | SQLite stored | Neo4j query-time | Neo4j stored |
| --- | --- | --- | --- | --- |
| Tariff witnesses | 11.6 [11.0–12.3] | 13.8 [12.2–14.3] | 93.5 [78.4–100.5] | 19.9 [17.9–21.9] |
| Source lineage | 25.1 [24.1–28.9] | 27.1 [26.6–29.1] | 160.5 [148.1–183.5] | 31.0 [29.9–34.8] |
| Rule and dictionary context | 38.0 [31.5–40.8] | 35.0 [33.0–52.1] | 216.3 [194.7–232.4] | 49.0 [38.9–57.4] |
| Combined SAI/SL context | 2715.5 [2502.1–2911.9] | 9676.7 [9496.2–10000.0] | 174.8 [159.5–189.0] | 32.8 [31.9–35.4] |
| Peers with indication evidence | 87.3 [74.5–92.8] | 266.7 [218.7–273.7] | 1296.0 [1167.5–1414.9] | 394.8 [348.9–422.6] |
| Route fields | 20.5 [19.4–22.2] | 22.4 [21.3–24.7] | 79.1 [72.6–89.7] | 20.9 [20.1–24.8] |
| Refreshed-source premises | 25.7 [24.8–30.2] | 27.7 [26.0–30.0] | 204.9 [171.2–223.7] | 38.8 [34.8–47.3] |

The registered comparison uses three warmups and fifteen randomized interleaved repetitions for every arm, task and source state. Timing includes HTTP execution, transfer and complete row consumption. The same predicates, records and answer multiplicities apply to both query-time and stored variants. The two source-premise tasks have identical outputs because both contributing sources are refreshed. Complete D0 distributions and all raw measurements remain in the experiment package.

Table 4. Exploratory join-order control on D1, median [Q1–Q3] milliseconds. All 180 outputs agree with reconstruction.

| Task | Variant | Query-time | Stored derivation |
| --- | --- | --- | --- |
| Combined context | SQLite automatic | 2891.4 [2584.1–2962.5] | 9974.3 [9494.6–10437.6] |
| Combined context | SQLite ordered | 38.7 [36.1–43.4] | 42.5 [38.5–46.5] |
| Combined context | Neo4j | 166.5 [147.4–176.5] | 37.0 [32.5–40.6] |
| Peers | SQLite automatic | 85.4 [75.7–88.6] | 267.7 [219.7–280.2] |
| Peers | SQLite ordered | 144.6 [125.8–154.0] | 195.7 [165.2–206.2] |
| Peers | Neo4j | 1372.1 [1155.0–1458.7] | 409.7 [378.6–431.3] |

CROSS JOIN retains every ON predicate while fixing the written loop order. This changes the SQL plan, not the result contract, indexes or information. The control evaluates an alternative loop order for the same tasks. Interleaving all six variants controls the comparison within the same D1 session.

Table 5. Loading and stored-derivation maintenance, median [Q1–Q3] milliseconds over seven cycles.

| Phase | Neo4j | SQLite |
| --- | --- | --- |
| Initial layer load | 5158.8 [4901.8–6000.3] | 647.4 [579.8–700.9] |
| Initial stored derivation | 109.8 [95.5–139.5] | 7.6 [7.4–8.4] |
| Stored derivation invalidation | 35.3 [17.9–81.8] | 3.5 [2.9–4.4] |
| Complete layer replacement | 8076.8 [7754.7–8941.8] | 779.1 [696.9–789.6] |
| Stored derivation reconstruction | 110.8 [84.8–176.3] | 7.1 [6.9–7.5] |

Neo4j loads parameterized batches through HTTP; SQLite uses committed local inserts. These are deployment-path costs. Source reconstruction precedes timing; payload serialization and loading are included. Constraints and indexes are prepared before the cycles. Each cycle replaces the complete layer, rather than applying an incremental algorithm. Stored derivations are invalidated separately and rebuilt against the new sources.

For implementation arm $a$, the reusable lifecycle calculation is $C_a = L_a + M_a + r(R_a + I_a + M_a^\prime) + \sum_q n_q T_{a,q}$. Here $L$ is initial loading, $M$ initial materialization, $r$ the number of replacements, $R$ base replacement, $I$ invalidation, $M^\prime$ rematerialization, and $n_q T_{a,q}$ the requests and retrieval cost for task $q$. Query-time arms set $M$, $I$ and $M^\prime$ to zero. Each phase and task cost is its repeated-measurement median. The model projects serial costs under reuse of the measured workload and replacement conditions.

The calculated scenario yields 5.30 s for ordered query-time SQLite and 17.19 s for stored Neo4j. It combines registered maintenance medians with the exploratory control's retrieval medians, preserving their separate measurement conditions. These are calculated scenario totals, not measured end-to-end runs.

Primary within-system totals use one build, one replacement and 1, 10, 100 or 1,000 requests. Break-even is the smallest request count recovering materialization and upkeep when the measured retrieval saving is positive. Paired bootstrap intervals use 5,000 resamples of the fifteen interleaved repetitions and seven maintenance cycles. They describe timing variation in the fixed deployment; the portable scenario calculator reports cost components without inferring new uncertainty intervals.

Within Neo4j, median-based break-even after one build and one replacement is four witness requests, two lineage requests, two rule-context requests, two combined-context requests and one peer request. Paired bootstrap 95% intervals are 3–6, 2–4, 2–3, 2–3 and 1–1 requests, respectively. These thresholds compare stored and query-time derivation within the same system.

The retained derivations comprise 1,559 initial and 1,589 D1 graph relationships or relational rows. SQLite allocates 888,832 additional bytes in the first initial materialization and 876,544 in the D1 materialization; subsequent cycles reuse allocated pages. Graph storage is reported as additional relationships because an isolated allocated-byte delta was not measured. The complete package preserves these conditions and raw outcomes.

### Classification-cycle inspection and SQL plan control

The exploratory task asks which pairs of distinct Association records connect the same product record to the same ATC concept. It matches the undirected pattern product–classification record–ATC concept–classification record–product, retaining the stored relationship directions. The lexically ordered Association identifiers suppress duplicate orientations. A cycle exposes repeated explanations for inspection; it is not itself an error or proof of independent confirmation.

Cases retain the pre-timing identifier selection: the first three tariff-associated Swiss products with a same-code peer, 31096, 41330 and 44470. Inputs comprise 84,672 nodes and 177,044 directed relationships from D1. Native Neo4j and indexed file-backed SQLite receive identical node and edge facts. All 38,211 exported source-row identities are checked against the frozen D1 CSVs. Complete output hashes agree, yielding 0, 1 and 0 cycles; missing-product controls return no rows. The Prothromplex cycle (41330, B02BD01) contains direct SAI and authorization-linked SL classification records. Both cite the same SAI source row; the latter adds the SL package row. Figure A2 therefore distinguishes converging paths from independent source evidence.

Three warmups and five randomized interleaved timed repetitions give Neo4j HTTP medians of 7.978, 8.974 and 7.317 ms and embedded SQLite medians of 33.576, 42.349 and 23.426 ms. In a subsequent within-SQLite control on the same server and file-backed database, automatic medians are 32.206, 22.312 and 18.737 ms, while fixed join order gives 0.034, 0.038 and 0.019 ms. The control changes only JOIN to CROSS JOIN, retaining all predicates and indexes; complete answers remain identical. It uses the same warmup and repetition counts and interleaves the SQL variants. Neo4j is not rerun during this control. Different interfaces and separate runs limit attribution of absolute timings; the control identifies SQL plan sensitivity behind the initial configuration advantage.

Offline reconstruction checks the source-bound graph facts, native answer hashes, absent-product controls and ordered-SQL answers. It also verifies that both Prothromplex paths share a source record; timings are retained from the native experiment. The display distinguishes converging explanations from shared provenance. Effects on review speed and understanding were not measured.

### Full-population and cross-source peer transfer

This task applies the same two comparisons as tariff review: source ablation measures the information gained, while equivalent database queries measure the cost of retrieving complete evidence. Hierarchical peer retrieval replaces tariff matching and route assessment.

Peer membership means sharing an admitted ATC code or an ancestor reachable within the selected depth on each side. Swiss entities are D1 authorization identifiers. ChEMBL entities retain molecule identifiers and their recorded ATC arrays; chemical parent families are not merged for this task. Starting codes must have seven characters and occur in the frozen ATC dictionary. Each code connects to its immediately preceding recorded prefix at lengths 1, 3, 4, 5 and 7; missing parents terminate traversal. The hierarchy follows the WHO Collaborating Centre’s ATC structure and principles (https://atcddd.fhi.no/atc/structure_and_principles/).

Separate SQL source adapters check the authorization/package join or expand the original ChEMBL JSON arrays, verifying every witness’s entity, code, source kind and source-row identity. Python prefix enumeration and independently expressed SQL closure queries compare peer membership for every eligible entity at depths zero, two and four. The source ablations remove Swiss package classifications or keep one lexically first admitted code per ChEMBL molecule. The latter is an information-loss control. Both full and reduced memberships are checked independently. Table 6 reports unordered pairs; directed answer hashes are retained for exact replay.

Table 6. Complete peer-membership census. Additional pairs and gaining entities compare all admitted codes with the corpus-specific ablation.

| Corpus | Depth | Entities | Unordered pairs | Additional pairs | Gaining entities |
| --- | --- | --- | --- | --- | --- |
| Swiss | 0 | 5,678 | 21,772 | 290 | 182 |
| Swiss | 2 | 5,678 | 187,667 | 4,632 | 1,130 |
| Swiss | 4 | 5,678 | 1,538,005 | 24,589 | 4,111 |
| ChEMBL | 0 | 3,647 | 0 | 0 | 0 |
| ChEMBL | 2 | 3,647 | 77,730 | 14,170 | 2,204 |
| ChEMBL | 4 | 3,647 | 740,716 | 97,849 | 3,240 |

The Swiss projection admits 5,678 authorizations and 9,014 classification witnesses. Seventy authorizations gain an admitted code through SL; 53 of these have no admitted direct code. ChEMBL contains 3,651 ATC-bearing records, of which four have no code admitted by the frozen dictionary. The 3,647 eligible records provide 4,563 witnesses; 559 records have multiple admitted codes and 314 span multiple first-level groups. Prednisolone (CHEMBL131) records thirteen codes across six first-level groups. These remain classifications of the named molecule record.

For native retrieval, each first-level group supplies the unselected entity minimizing SHA256 of `breadth-20261025:<corpus>:<group>:<entity>`, yielding fourteen anchors per corpus. Entities are independently hash-ranked by `growth-20261025:<corpus>:<entity>`. Nested subsets retain the first ceiling of 10%, 40% or 100% of this order plus every anchor. Only codes used by retained entities and their recorded ancestors are loaded. No entities, classifications or edges are duplicated or invented. Table 7 reports the actual resulting sizes and branch structure.

Table 7. Real-entity growth and structural variation. Leaf occupancy counts source-kind witnesses, so two Swiss sources may support the same entity/code. ChEMBL records can carry several distinct codes.

| Corpus | Entities | Witnesses | ATC nodes | Occupied leaves | Max witnesses/leaf | Max children |
| --- | --- | --- | --- | --- | --- | --- |
| Swiss | 582 | 921 | 982 | 447 | 11 | 12 |
| Swiss | 2,283 | 3,616 | 1,904 | 1,122 | 40 | 14 |
| Swiss | 5,678 | 9,014 | 2,678 | 1,782 | 78 | 24 |
| ChEMBL | 379 | 488 | 1,044 | 488 | 1 | 12 |
| ChEMBL | 1,467 | 1,830 | 2,725 | 1,830 | 1 | 18 |
| ChEMBL | 3,647 | 4,563 | 5,616 | 4,563 | 1 | 41 |

All native variants use the unchanged witness/parent schema and the same SQL or Cypher text across corpora. The complete explanation output contains both entity keys, both codes and witness identifiers, both source-record lists, the common ancestor and each path depth. This native contract is richer than the membership-only census. Each native result is checked against Python’s complete explanations outside timing.

The comparison uses Linux, Python 3.12.3, Neo4j Community 5.26.1, file-backed SQLite 3.45.1 and PostgreSQL 16.13. Neo4j uses a 1–2 GB heap and 1 GB page cache; PostgreSQL uses 1 GB shared buffers and 64 MB work memory with JIT and synchronous commit enabled. SQLite uses default connection settings. SQL indexes cover entity lookup, code lookup and both hierarchy directions; ANALYZE follows loading. Neo4j has unique witness/code keys and an entity lookup index. Full local HTTP transfer and decoding are timed. SQL uses a Python bridge with sqlite3 or psycopg2 2.9.11; Neo4j uses its native transactional HTTP endpoint. Sorting and correctness comparison occur outside timing.

Five variants—Neo4j, global and anchor-started recursion in each SQL engine—are interleaved after two warmups, with nine repetitions per condition. Two corpora, three real-entity sizes and three depths give 810 timed outputs, all agreeing with their full explanations. Absent anchors yield no answers in every variant. Table 8 reports every condition; individual repetitions, quartiles and all query plans remain in the reproduction package. These exploratory measurements use fixed anchor-selection and subset rules across all engines.

Table 8. Native peer-retrieval medians in milliseconds. SQL cells give global / anchor-started recursion. Corpus labels and entity counts identify the subsets in Table 7; rows count complete explanation records.

| Corpus/entities | Depth | Rows | Neo4j | SQLite G / A | PostgreSQL G / A |
| --- | --- | --- | --- | --- | --- |
| Swiss 582 | 0 | 28 | 15.11 | 4.05 / 2.36 | 21.68 / 4.39 |
| Swiss 582 | 2 | 231 | 20.03 | 9.70 / 4.58 | 120.65 / 8.13 |
| Swiss 582 | 4 | 1,864 | 56.57 | 33.07 / 30.30 | 709.67 / 28.94 |
| Swiss 2,283 | 0 | 122 | 11.02 | 5.60 / 4.75 | 30.77 / 4.86 |
| Swiss 2,283 | 2 | 979 | 27.69 | 23.57 / 17.58 | 357.06 / 16.03 |
| Swiss 2,283 | 4 | 7,510 | 151.62 | 94.41 / 92.78 | 3116.81 / 68.21 |
| Swiss 5,678 | 0 | 243 | 12.63 | 8.85 / 8.82 | 54.00 / 6.53 |
| Swiss 5,678 | 2 | 2,337 | 51.74 | 45.11 / 33.16 | 1029.51 / 24.74 |
| Swiss 5,678 | 4 | 18,583 | 323.67 | 225.25 / 215.83 | 9673.72 / 159.95 |
| ChEMBL 379 | 0 | 0 | 7.15 | 2.90 / 1.93 | 10.74 / 1.83 |
| ChEMBL 379 | 2 | 102 | 10.03 | 5.75 / 3.03 | 58.47 / 4.07 |
| ChEMBL 379 | 4 | 984 | 22.00 | 14.74 / 13.64 | 401.18 / 12.77 |
| ChEMBL 1,467 | 0 | 0 | 7.36 | 6.57 / 2.18 | 30.89 / 2.61 |
| ChEMBL 1,467 | 2 | 420 | 16.43 | 25.75 / 8.91 | 87.19 / 11.57 |
| ChEMBL 1,467 | 4 | 3,806 | 81.98 | 71.35 / 58.86 | 161.08 / 40.06 |
| ChEMBL 3,647 | 0 | 0 | 7.51 | 10.55 / 3.99 | 11.25 / 5.18 |
| ChEMBL 3,647 | 2 | 1,001 | 28.15 | 57.32 / 19.29 | 32.31 / 21.35 |
| ChEMBL 3,647 | 4 | 9,488 | 204.11 | 182.17 / 150.36 | 129.76 / 130.57 |

ChEMBL’s empty depth-zero result follows from one molecule witness per leaf in this source population and is also obtained by the full census. At greater depths, shared ancestors generate nonempty comparisons. The pronounced full-Swiss PostgreSQL difference occurs between equivalent query formulations with the same source records, indexes and settings. The measurements therefore distinguish query execution from changes in analytical content. They concern bounded ATC traversal and the stated local interfaces.

## Optional information acquisition

This secondary analysis asks which missing source fields would make more comparisons answerable. It does not enter the database-selection results. Complete field-level outcomes, finite-domain checks, sensitivity analyses and cost measurements are retained in the reproduction package.

### Rules and comparison

A question has fixed source-field witnesses and tariff or route options. Unknown fields range over finite admitted domains; repeated references to one field share its value. A missing identity bridge remains undetermined. Revealing a field restricts its admitted values while preserving the other witnesses and option meanings. The minimum and maximum numbers of questions resolved across all admissible revelations define conditional gain bounds. These bounds describe single-field gains, not a globally optimal acquisition sequence. Complementary fields can resolve a question only together, while redundant fields can resolve the same question.

For Swiss routes, domains distinguish oral, parenteral and unknown families; residual OTHER categories retain uncertainty. The independent finite-world reference checks 320 fixtures, 980 completed worlds and 196 preservation probes. The methodological precursors are manuscript references 38–41.

Selectors observe masked fields, reveal their archived values one at a time and recompute gains. Bounds rank by guaranteed gain, then possible gain and affected unresolved questions. Degree ranks by affected unresolved questions; interpreted degree excludes questions with unavailable option meanings. Source identities break ties. Budgets count equally costly fields. Random comparisons use 128 seeded orders.

### Route and strength findings

Simultaneous route masking covers 37 eligible D0 parenteral fields across eighteen authorizations and seven ATC groups. The EMA cohort comprises the thirteen medicines selected by recorded L04AC05 before document retrieval (Supplementary references S4.1–S4.13). Nine have complete inventories documenting IV and SC; Qoyvolma, Imuldosa, Usrenty and Yesintek have unavailable inventories under the extraction rule. Eighteen source medicine–route assertions yield 216 directed comparisons: 144 compatible and 72 with unavailable targets. These are repeated documentary comparisons, not independent clinical findings. Masking the nine complete inventories gives sixteen clarifications per revealed inventory, so every acquisition order has equal yield. SQL and native Cypher reproduce the fixed judgments and budget outcomes.

Table 9. Complete frozen budget outcomes; values are resolved questions. Random outcomes are median [minimum–maximum] across 128 orders.

| Dataset | Budget | Bound-first | Unresolved degree | Random |
| --- | --- | --- | --- | --- |
| D0 | 1 | 2 | 2 | 1 [0–2] |
| D0 | 2 | 4 | 4 | 2 [1–4] |
| D0 | 5 | 9 | 9 | 5 [3–7] |
| D0 | 10 | 14 | 14 | 8 [5–12] |
| D0 | 20 | 22 | 22 | 15 [8–19] |
| D0 | 37 | 22 | 22 | 22 [22–22] |
| EMA | 1 | 16 | 16 | 16 [16–16] |
| EMA | 2 | 32 | 32 | 32 [32–32] |
| EMA | 5 | 80 | 80 | 80 [80–80] |
| EMA | 9 | 144 | 144 | 144 [144–144] |

The strength-field analysis asks whether any linked presentation records a strength numerator in the mass family required by a mass-denominated tariff. Numeric g/mg/mcg/ug/µg tokens map to mass; IU/UI/IE map to activity. Concentrations retain their numerator family. Container volume, ambiguous strengths and generic tariff U/AN/UD remain uninterpreted. This assesses recorded unit families; administered dose requires additional case-specific information (Supplementary references S4.14–S4.15).

Of 837 D0 fields, 818 have interpreted strengths, supporting 369 of 564 questions. Masking these strengths makes every question undetermined. At budgets five and twenty, bounds and interpreted-degree ranking both clarify ten and forty questions; raw degree clarifies zero and six. Bounds therefore add conditional assurance, while the simpler semantically filtered ranking matches their observed yield. Native Cypher authenticates all fields and reproduces the judgments and budget comparisons.

### Costs and interpretation

Seven warm-cache repetitions after one warmup measure complete planning separately from source parsing. At budget five, median planning is 75.05 ms for bounds and 2.38 ms for interpreted degree, both clarifying ten questions. At budget twenty, the corresponding values are 76.47 and 7.49 ms, both clarifying forty. The complete SL scan takes median 35.73 ms and strength extraction 3.20 ms. These measurements distinguish the cost of assurance from observed selection yield.

A retrospective EMA replay calibrates extraction costs on three repetitions and evaluates four later repetitions of the same nine complete inventories. Each inventory clarifies sixteen questions. For five inventories, cost ranking sums to 3,524.38 ms, compared with 4,960.32 ms in name order and a random median of 4,479.13 ms. At full budget, every order has the same summed extraction cost. The totals exclude planning, network and human interpretation; calibration and evaluation reuse the same documents. Individual timings and all budget results remain in the reproduction package.


## Exploratory curation, aggregation and evidence-availability analyses

The curation, aggregation and workload-coverage analyses were specified after the timing experiments and are treated as exploratory. They use the fixed source states and recorded answers and introduce no additional latency observations. A separately implemented lexical route policy reconstructs each package judgment; SQL GROUP BY verifies every candidate's V/C/U counts, including zero counts for candidates without packages (Supplement S5). Agreement establishes consistency with the declared policy.

Table 10. Complete package-judgment profiles. V/C/U columns count candidates whose contributing packages all have that judgment under the selected policy. There are no mixed profiles of any kind in either population. The no-package category remains separate from all-U package evidence.

| State | Policy | All V | All C | All U | No package | Mixed |
| --- | --- | --- | --- | --- | --- | --- |
| D0 | Coarse | 388 | 37 | 2 | 137 | 0 |
| D0 | Exact route | 102 | 36 | 289 | 137 | 0 |
| D0 | Formulation qualified | 92 | 25 | 310 | 137 | 0 |
| D1 | Coarse | 396 | 37 | 4 | 138 | 0 |
| D1 | Exact route | 103 | 36 | 298 | 138 | 0 |
| D1 | Formulation qualified | 93 | 25 | 319 | 138 | 0 |

The existential summary returns V if any package is V, C only when every package is C, and U otherwise. The unanimous alternative returns V only if all packages are V, C only if all are C, and U otherwise. The conflict-first alternative returns C whenever any package is C, otherwise V if any is V and U otherwise. With no packages, all return U. No alternative changes a candidate summary in either state. A more conservative request rule prioritizes any finer-policy package conflict over missing fields; it changes no request and retains the same twelve changed shared keys and 31 full monitoring alerts. This is population-specific invariance, not a general equivalence of aggregation operators.

Table 11. Exact-route to formulation-qualified transitions for package–tariff comparisons. Missing admitted form wording removes determinacy in the qualification field while the exact-route field is retained.

| Transition | D0 paths | D1 paths |
| --- | --- | --- |
| V to V | 279 | 281 |
| V to U | 13 | 13 |
| C to C | 70 | 70 |
| C to U | 14 | 14 |
| U to U | 623 | 640 |
| Total | 999 | 1018 |

For example, Noxafil's oral suspension has an oral group and a package title containing Susp; the formulation filter admits tablet/capsule tokens for oral products, so its oral-versus-IV route conflict remains in exact-route output but its formulation-qualified field is U. Vfend suspension, Abilify syrup and Schmelztabl, and Voriconazol-Mepha Lactabs provide further concrete token-boundary examples in the path census. Missing output means the required evidence is unavailable to that lexical rule. Infusion wording without an admitted route token remains U under the exact policy; it is not automatically interpreted as IV. The lexical policy has not been independently validated for population extraction accuracy.

### Influence of inherited ATC overrides

The curation sensitivity changes only the audited SAI ATC fields and holds authorization identities, other staging fields, SL packages, tariffs and policies fixed. D0 raw codes are taken from the archived attribution certificates, bound to original archive identity and staged row identity; this is a seven-field reversal, not a new complete raw-XML reconstruction. D1 original codes are read directly from the frozen Refdata XML and compared with all 6,354 admitted staging rows. Six rows differ; each has a unique raw code. These six replacements are then replayed through the same candidate and judgment definitions.

Table 12. Candidate-source coverage after ATC-edit reversal. Complete candidates and all shared route judgments are preserved. No removal or addition occurs in either state.

| State/view | Direct | SL only | Complete |
| --- | --- | --- | --- |
| D0 curated staging | 560 | 4 | 564 |
| D0 seven edits reversed | 557 | 7 | 564 |
| D1 curated staging | 571 | 4 | 575 |
| D1 six edits reversed | 569 | 6 | 575 |

D0 authorizations 65920, 66495 and 67278 retain SL-supported candidates while losing direct support. Thus source gain depends on the preprocessing baseline even when the complete candidate set is stable. All measured database configurations use the same curated staging; execution times and transfer-corpus counts refer to that source view. Record-level differences, complete profiles, alternative summaries and source checksums are supplied in S5.

### Documentary assessment sample

The sampling unit is a D0 package-record–tariff comparison. Deterministic hash selection samples up to twenty comparisons from each of the eight observed three-policy outcome strata, producing 101 cases. All cases from strata with at most twenty comparisons are included, including the six SC–IV paths. Stratum populations of 64/14/6/2/6/615/13/279 yield allocations of 20/14/6/2/6/20/13/20. The packet withholds algorithm outcomes and stratum membership while retaining product identifiers, package text, tariff requirements and source coordinates. This packet defines the reference sample; ancillary extraction procedures are described in S8.

The sample overrepresents rare outcome transitions and excludes comparisons without package evidence. Repeated packages, authorizations and documents induce dependence. Current-document readings cannot establish historical D0 continuity; consequently, neither unweighted population accuracy nor D1 or prospective clinical performance is estimated. The separate professional-review design in S5 was not executed.

## Workload coverage and primary route displays

Main Table 4 and Figures 2–3 compare the coarse and exact-route policies. Figure 2 distinguishes 999 package comparisons from 564 candidate summaries. Figure 3 and Table A4 report coarse/exact agreement by classification support: both-source candidates have 100 stable positives, 31 stable conflicts, 290 changing summaries and two undetermined throughout; SAI-only candidates have 137 undetermined throughout; SL-only candidates have two stable positives and two changing summaries.

The workload census uses the same eligible entities, witness records, parent hierarchy and hash-selected anchors as the native experiment. For each entity and depth, reachable-ancestor enumeration and inverted memberships yield distinct peer counts. Summed memberships agree with the separately checked census. Complete explanations for the fourteen fixed anchors reconcile with native batch row counts. These counts characterize workload coverage, not additional latency observations.

Table 13. Coverage of the fixed native anchors in the full-population peer-count distributions. Population median and maximum describe distinct peers; explanation concentration describes the different, provenance-rich native output. The largest share is undefined for an empty batch. Each native timing observation concerns the complete fixed batch.

| Corpus | Depth | Population median / max peers | Selected-anchor peer range | Batch explanation rows | Largest anchor share |
| --- | --- | --- | --- | --- | --- |
| Swiss D1 | 0 | 5 / 66 | 0–34 | 243 | 51.0% |
| Swiss D1 | 2 | 54 / 328 | 1–93 | 2,337 | 22.9% |
| Swiss D1 | 4 | 552 / 874 | 22–874 | 18,583 | 20.1% |
| ChEMBL 37 | 0 | 0 / 0 | 0–0 | 0 | Undefined |
| ChEMBL 37 | 2 | 35 / 208 | 1–146 | 1,001 | 16.9% |
| ChEMBL 37 | 4 | 409 / 1,593 | 81–831 | 9,488 | 12.7% |

The group-spanning selection does not cover every high-degree case: the largest Swiss depth-two and ChEMBL depth-four neighborhoods exceed those of the selected anchors. At Swiss depth zero, one anchor contributes over half the full batch's explanations. It follows that batch latency cannot be interpreted as typical per-entity latency, even when every returned explanation is correct. The complete distributions, anchor weak percentiles, source-scoped identities and per-anchor explanation counts are in S5 (`focus_analysis.json`, `scope_population.csv`, `scope_anchors.csv`). Weak percentile is the percentage of population entities with peer count less than or equal to that anchor; ties are not broken. Quantiles use the nearest-rank empirical convention. No population latency ranking or confidence interval across deployments is estimated.

Primary-policy monitoring was reconstructed without the ancillary formulation field: ten shared candidates change at least one coarse/exact summary. Thus the 19→29 membership-plus-judgment alert count is preserved when only primary route judgments are monitored. The original request categories continue to yield the documented twelve changed shared requests and 31 complete alert keys.


## Documentary assessment and catalogue scope

Official identifier/classification concordance and selected Swiss–EU route comparisons are documented in S7. Ancillary extraction checks, their technical assistance and validity limits are summarized in S8.

The frozen tariff table is a base-definition projection that pools SwissDRG ZE, TARPSY TZE and ST Reha RZE. D0 has 535/26/3 candidates in these scopes; D1 has 545/27/3. The 185 input definitions comprise 182/2/1, retaining V15.3/T6.3/R3.3. All 182 ZE signatures match official November 2025 and April 2026 source fields, and separate official TARPSY/ST Reha documents corroborate the other three routes. The official November 2025 EDV documentation explicitly refers the va field to the 2023 technical companion, Section 3.1.c. Dose-band and product-specific billing conditions remain outside the route comparison. Complete source URLs, checksums, scope tables and analysis are in S6.


## References for ancillary information acquisition

S4.1. European Medicines Agency. Uzpruvo: English EPAR product information. https://www.ema.europa.eu/en/documents/product-information/uzpruvo-epar-product-information_en.pdf (retrieved 11 October 2026; document identity in the experiment manifest).

S4.2. European Medicines Agency. Usgena: English EPAR product information. https://www.ema.europa.eu/en/documents/product-information/usgena-epar-product-information_en.pdf (retrieved 11 October 2026; document identity in the experiment manifest).

S4.3. European Medicines Agency. Stelara: English EPAR product information. https://www.ema.europa.eu/en/documents/product-information/stelara-epar-product-information_en.pdf (retrieved 11 October 2026; document identity in the experiment manifest).

S4.4. European Medicines Agency. Steqeyma: English EPAR product information. https://www.ema.europa.eu/en/documents/product-information/steqeyma-epar-product-information_en.pdf (retrieved 11 October 2026; document identity in the experiment manifest).

S4.5. European Medicines Agency. Qoyvolma: English EPAR product information. https://www.ema.europa.eu/en/documents/product-information/qoyvolma-epar-product-information_en.pdf (retrieved 11 October 2026; document identity in the experiment manifest).

S4.6. European Medicines Agency. Imuldosa: English EPAR product information. https://www.ema.europa.eu/en/documents/product-information/imuldosa-epar-product-information_en.pdf (retrieved 11 October 2026; document identity in the experiment manifest).

S4.7. European Medicines Agency. Otulfi: English EPAR product information. https://www.ema.europa.eu/en/documents/product-information/otulfi-epar-product-information_en.pdf (retrieved 11 October 2026; document identity in the experiment manifest).

S4.8. European Medicines Agency. Fymskina: English EPAR product information. https://www.ema.europa.eu/en/documents/product-information/fymskina-epar-product-information_en.pdf (retrieved 11 October 2026; document identity in the experiment manifest).

S4.9. European Medicines Agency. Wezenla: English EPAR product information. https://www.ema.europa.eu/en/documents/product-information/wezenla-epar-product-information_en.pdf (retrieved 11 October 2026; document identity in the experiment manifest).

S4.10. European Medicines Agency. Usrenty: English EPAR product information. https://www.ema.europa.eu/en/documents/product-information/usrenty-epar-product-information_en.pdf (retrieved 11 October 2026; document identity in the experiment manifest).

S4.11. European Medicines Agency. Yesintek: English EPAR product information. https://www.ema.europa.eu/en/documents/product-information/yesintek-epar-product-information_en.pdf (retrieved 11 October 2026; document identity in the experiment manifest).

S4.12. European Medicines Agency. Usymro: English EPAR product information. https://www.ema.europa.eu/en/documents/product-information/usymro-epar-product-information_en.pdf (retrieved 11 October 2026; document identity in the experiment manifest).

S4.13. European Medicines Agency. Pyzchiva: English EPAR product information. https://www.ema.europa.eu/en/documents/product-information/pyzchiva-epar-product-information_en.pdf (retrieved 11 October 2026; document identity in the experiment manifest).

S4.14. SwissDRG AG. Klarstellung zur Abrechnung der Zusatzentgelte nach SwissDRG Abrechnungsversion 15.0 sowie zur Kodierung der Medikamente/Substanzen. Version 2 December 2025, pp. 1–4. https://www.swissdrg.org/application/files/5617/6466/7335/Klarstellung_zur_Erfassung_der_Zusatzangabe.pdf (accessed 11 October 2026).

S4.15. Bureau International des Poids et Mesures. The International System of Units (SI), 9th ed.; updated 2026. https://doi.org/10.59161/AUEZ1291.


## Operationalizing configuration selection

The selection unit is the engine, derivation strategy, query formulation, source state and interface together. The tariff plan control provides six measured choices: automatic or ordered SQLite with query-time or stored derivation, and query-time or stored Neo4j. PostgreSQL participates in peer retrieval, but lacks comparable tariff loading/replacement measurements. It is not assigned hypothetical lifecycle costs.

The seven tariff tasks deliberately span required answer structures rather than frequencies observed in production: candidate lookup tests linking paths; source lineage tests provenance retrieval; rule/dictionary context tests interpretation support; combined SAI/SL context tests wide cross-source joining; peers with indication evidence test connected-product/context retrieval; route fields test qualification; refreshed premises test update inspection. Peer retrieval additionally varies hierarchy depth and nested entity populations. These choices do not cover concurrent service load, cold-cache behavior, arbitrary user queries or the unselected tails of per-entity latency.

For the calculated decision analysis, one initial build is followed by r full replacements and n requests. A declared fraction p uses combined-context retrieval; the remainder use the tariff peer/indication query. This query is distinct from the hierarchical classification-peer transfer task. Fixed costs and retrieval costs come from the archived phase measurements and the separate D1 plan control. Counts are hypothetical planning inputs, not measured clinical frequencies. Initial loading was measured for D0 and control latencies for D1: zero-replacement scenarios use the former as a load-cost proxy rather than an observed same-snapshot lifecycle. Repeated replacements reuse the measured full-replacement unit cost. Source growth, temporal changes in cost, network variation and amortization of incremental updates are not inferred. Supplement S9 supplies all six configurations, an expanded 600-scenario grid, exact integer crossovers and a standalone curve plot. The revised grid combines 10, 100, 1,000, 10,000 and 100,000 requests with zero, one, two, five, ten, 20, 50, 100, 200 and 1,000 full replacements, and context shares of 0, 0.5, 0.9, 0.95, 0.98, 0.99, 0.993, 0.9935, 0.9936, 0.994, 0.999 and 1. The high replacement counts are stress scenarios and assume unchanged unit costs. Under component-quartile bounds, 490 cells separate SQLite at engine level and 110 remain unresolved. Grid-cell counts do not estimate the prevalence of real workloads.

For each scenario, the analysis evaluates the median projection and corners obtained by replacing every component with its recorded Q1 or Q3. These are deterministic rectangular sensitivity bounds, not a joint confidence interval, an estimated probability of winning or a prediction for another deployment. A second bound perturbs every positive cost component independently by ±10%. Strict separation requires one candidate's upper cost to be below every competitor's lower cost. Overlap leaves the choice unresolved under the declared bounds; it does not demonstrate statistical equivalence.

Engine-level intervals use the minima of lower and upper configuration bounds within each tested engine. They can separate an engine while leaving its internal strategy unresolved. For one replacement and 100 pure context requests, SQLite is separated from Neo4j, although query-time and stored SQLite overlap. At 10,000 requests, the median advantage of stored Neo4j over ordered query-time SQLite is 5.05 s, but the component bounds overlap; the relative perturbation needed to reverse the leading median configurations is approximately 0.65%. A 1% tariff peer/indication request share reverses that median preference. These analyses characterize sensitivity of a serial projection, not sustained native throughput.

Table 14. Additional local acceptance criteria. These requirements are not scored or weighted by the present timing study.

| Criterion | Evidence required for a local decision | Coverage in this study |
| --- | --- | --- |
| Auditability | Reproduce keys, premises, multiplicity and update-state provenance | Complete source-linked answers checked; human audit performance unmeasured |
| Maintainability | Specify a schema/rule change, implement it and record effort, regressions and ownership | Executable source/rule checks available; development effort not measured |
| Integration | Verify required client APIs, authentication, deployment model and error behavior in the target environment | Local interfaces documented; production integration acceptance unmeasured |
| Resource and service constraints | Test actual memory, cold starts, concurrency and required response-time limits | Allocated settings and serial warm timings documented; service-level compliance unmeasured |
| Reviewer usability | Define a review task and evaluate completion time, errors and comprehension with intended users | Graph paths and relational provenance available; no user evaluation |

Table A9 in the manuscript records which of the six procedural steps transfers between tariff review and classification peers. The broad peer membership census does not create additional lifecycle measurements or representative latency observations. A local decision requires explicit acceptance evidence for any criterion used as a hard constraint; an unmeasured constraint remains open rather than receiving an assumed favorable score.


## Worked source update and human review

The following source-bound cases distinguish candidate discovery, documentary judgment and the next evidence request. Both candidates exist in both frozen source states. The update does not create a new clinical indication or establish payment entitlement.

Retsevmo film-coated tablets, authorization 70214, directly match ZE-2026-263 through recorded ATC L01EX22. D0 has no linked SL package for this authorization, so all three route/formulation-policy summaries are undetermined and the workflow requests package evidence. D1 contains two matching package records, Retsevmo Filmtabl 40 mg and 80 mg (56 tablets each), whose recorded group is Retsevmo Oral. All three policy summaries become compatible and the next request becomes retain supported context. The package premises are rows 7788 and 7789 of sl.csv with SHA-256 03ff8ff406e30018b5a500ca009a6771656944f160ccbf093059ccc782f00928. The candidate retains its unchanged tariff-record identity, while the new package and SAI premises retain their respective source snapshots.

Bortezomib Zentiva, authorization 68344, retains its ZE-2026-51 candidate. D0 package rows 1181 and 1182 describe 1 mg and 3.5 mg presentations and the group Bortezomib Zentiva Parenteral. Coarse assessment is compatible, but exact-route and formulation-qualified assessment are undetermined; the next request is obtain explicit route. D1 has no linked package records for this authorization, all three summaries become undetermined and the next request changes to obtain linked package evidence. The removed premises belong to D0 sl.csv with SHA-256 8170c468ed391bd93a3cb8119d338296faa887053d9498bf2f5f2d6f887b2651.

A reviewer starts from the stable authorization and tariff key, inspects the cited package and versioned source fields, and checks whether the documentary route refers to the relevant presentation and date. Missing or conflicting evidence remains visible and is escalated for source retrieval or specialist assessment. Any additional document is recorded with its own identity, version and date before the rule is rerun. Other payment conditions are assessed separately. The archived selected_cases.json contains the complete before/after source coordinates, judgments and next requests; these cases were independently reconstructed during revision. They do not measure human review performance.


## Reproducibility of the historical configuration comparison

The historical tariff study used Linux 6.8.0-117-generic x86_64 with glibc 2.39, Python 3.12.3, SQLite 3.45.1 and Neo4j Community 5.26.1. The host reported an Intel Xeon Silver 4416+, 80 logical CPUs and 1,081,833,316,352 bytes physical RAM. Neo4j's initial/maximal heap was 1/2 GiB and its page cache 1 GiB. Historical engine-only RSS, host-wide cache residency and a matched SQLite memory cap were not recorded; current settings are not substituted for those missing historical observations.

SQLite's shared schema uses primary keys for products, concepts, snapshots, rules, source records, witnesses, indication records and tariffs, together with composite primary keys on witness–premise and witness–tariff pairs. Additional indexes cover witness(code), witness(product,rule), witness(jurisdiction,rule), premise(record,witness), tariff(code), record(file), indication(product) and candidate(tariff,witness). ANALYZE is run after loading and materialization before retrieval; the ordered control substitutes CROSS JOIN for inner JOIN while retaining every ON predicate. The frozen query strings and EXPLAIN QUERY PLAN outputs accompany the archived receipts.

Neo4j uses unique id constraints on SourceRecord, ProductRef, Association, IndicationAssertion, SourceSnapshot, Rule and ATCConcept. Range indexes cover Association(jurisdiction,rule), Association(subject,rule) and SourceRecord(file,tariff_atc); index availability is awaited before execution. Loading uses batches of 500 rows over local transactional HTTP. SQLite uses local committed inserts. These native loading paths remain different and loading costs are deployment costs. Query-time and stored variants use the same original source premises; stored matches are rebuilt after complete source-layer replacement.

Retrieval timing begins before each HTTP request and ends after all rows have been received and decoded. Source identities, all returned fields and row multiplicities are checked outside the timed interval against the independent CSV reference. Warmups and randomized interleaving are specified in the main Methods; cache warmth is achieved through these queries without flushing the host's shared operating-system cache. No CPU exclusivity or cold-cache claim is made. The new reviewer-requested controls are reported separately in Supplement S10, with their actual current environment, read-back memory parameters and directly measured whole-workflow boundaries.


## Detailed source and execution protocol

The following details accompany the shortened main Methods. The complete executable SQL and Cypher formulations are retained in the source-bound query files and control archives. References in this section refer to the main manuscript.


The experimental workflow has five steps. First, freeze the source files, retain their identities and distinguish recorded from curated fields. Second, generate product–tariff candidates and assess the documented route under explicit rules. Third, compare source states and determine which evidence a reviewer still needs. Fourth, require every implementation to return the same complete answers. Fifth, measure construction, replacement and retrieval costs and calculate clearly specified workload scenarios (Figure 1). A database can execute an answer faster without adding information; a source can add information without favoring either database model.

Let A(S,R) denote the answer multiset for source state S and interpretation rules R. Source ablations and replacement vary S; route-resolution comparisons vary R. Execution comparisons hold both fixed and require each implementation to reproduce the reference answer, including entity keys, interpretation fields, source-record identities and row multiplicities. Swiss authorization identifiers anchor product records, while the Swiss Specialities List (SL) supplies distinct package records. Counts describe the frozen populations; repeated packages, documents and measurements are not independent observations.

A candidate is one distinct product–tariff-definition pair. The tariff table projects terminal dose-band rows to base definition keys, retaining ATC, route, dose unit and qualifier. Candidates are counted at the base-definition level; the applicable dose band remains outside this analysis. A linking path identifies the product classification and source records supporting a candidate. A package–tariff comparison assesses the route recorded for one package against the tariff definition. Counts of candidates, linking paths and package comparisons are reported separately from evidence-request categories.

### Detailed Source states and matched data models

The reference dataset (D0) comprises thirteen extracts with 38,147 records: the Refdata SAI product-authorization extract, the Swiss Specialities List (SL), European Medicines Agency (EMA) metadata, classifications and a pooled SwissDRG AG tariff-definition extract [42–43]. The replacement dataset (D1) contains 38,211 records and differs only in its SL and Refdata extracts [44–45]; the remaining eleven extracts, including the tariff catalogue, are identical. Candidate discovery and route assessment use SAI product classifications, authorization-linked SL records, the tariff catalogue and its route glossary. WHO alterations provide historical classification context; selected EMA documents and the EDQM vocabulary check route interpretation. The remaining D0/D1 sources supply context for broader retrieval tasks. A separate ChEMBL 37 corpus supplies molecule-level ATC assignments for transfer evaluation [46].

The tariff extract has 185 base definitions: 182 SwissDRG ZE, two TARPSY TZE and one ST Reha RZE, retaining versions V15.3, T6.3 and R3.3. Tariff provenance was assessed by comparing the 182 ZE signatures with the official machine-readable releases of 28 November 2025 and 9 April 2026. The compared fields were ATC, route, dose unit and qualifier. The remaining three definitions were checked against the corresponding TARPSY and ST Reha catalogues (Supplement S6).



Each staging row retains its source-file checksum, row number and version. Equal, nonempty Swiss authorization numbers link SAI products to SL packages. The link groups packages under a shared authorization while preserving their strength- and presentation-specific identifiers. European identities are not merged with Swiss authorizations. The integration pipeline contains 22 configured ATC overrides [42]. Seven D0 and six D1 fields differ from raw recording. The curation intervention reverses these edits while holding all other staging fields, packages and tariffs fixed. D0 raw values are identified by source-bound attribution certificates; D1 values are additionally checked against frozen XML for all 6,354 admitted rows. All database variants use the same curated staging view.

For tariff review in Neo4j, an Association node connects a product’s recorded ATC classification to its source rows, linking rule and dictionary version. The D1 snapshot with stored tariff links contains 84,672 nodes and 177,044 directed relationships. Its 8,416 ProductRef entities comprise 6,354 Swiss authorization references, 1,569 EMA medicine references and 493 German G-BA trade-name references; these source-specific references are not a deduplicated international product count. The remaining nodes comprise 38,211 source records, 2,196 ATC concepts, 18,371 classification associations, 17,461 indication assertions, thirteen source snapshots and four rules.

Relationships comprise 175,455 source, classification and provenance links plus 1,589 materialized CachedTariff links. These graph counts describe the D1 stored-derivation snapshot; the D0 candidate population and the separate ChEMBL corpus have their own denominators. SQLite represents the same entities and links in related tables. Source rows are loaded before entity links, with uniqueness constraints on identifiers. Independent reconstruction from the source files checks the resulting links, providing a common reference for the source and implementation comparisons (Figure 1).



### Detailed Candidate generation and route assessment

Candidates arise through direct equality between SAI and tariff ATC codes or through an authorization-linked SL package whose recorded ATC code matches the tariff. Comparing the two results measures what the package-linked classification adds. Explicit rules describe these sequences of links [49]; SQL joins implement the same connections. Historical codes and European references are kept in their separate source contexts.

Each comparison retains product identity and source fields [21–22] and is classified as route-compatible (V), route-conflicting (C) or undetermined (U) under the documentary rule. Archived machine labels VERIFIED, CONTRADICTED and UNDETERMINED map to these scoped outcomes. Missing or uninterpretable fields give U. SHACL validates the specified source links and fields [24, 60] (Supplement S1).



The primary route analysis compares coarse oral/parenteral grouping with exact recorded routes such as intravenous (IV) and subcutaneous (SC), using the SwissDRG glossary [50]. Exact assessment retains the recorded oral category but requires an admitted explicit code for parenteral products. A comparison is V when recognized routes overlap tariff options, C when fully interpreted routes are disjoint, and U otherwise. Generic parenteral or infusion wording alone does not establish an exact route.

Candidates without linked package evidence are U. For candidates with packages, any V gives V; otherwise all C gives C, and the remaining profiles give U. V/C/U package counts and the no-package category are retained separately. Unanimous and conflict-first alternatives assess aggregation sensitivity (Supplement S5). Linking-rule ablations preserve package context, and route-policy comparisons preserve candidate membership.

An ancillary formulation-token filter tests whether selected dosage-form words occur alongside an exact route (Supplement S4). Missing tokens make this separate field U without changing the exact-route judgment. The filter contributes to the evidence-request rule but is not a clinical formulation reference.

Presentation-specific route evidence was examined using selected EMA sections [51–58], EDQM concepts [59] and an outcome-stratified sample of 101 D0 package–tariff comparisons. Official Swissmedic lists provided current authorization and pack references [90]. Eight selected Swiss–EU cases were compared by ingredient, strength and formulation/device, with national identities kept separate [53–56, 84, 91]. Appendix A.4 specifies reference matching and source limitations; Supplements S6–S7 provide source metadata and replayable comparisons. Supplement S8 describes ancillary extraction procedures.

The paired queries return one row per linking path and tariff. An Association node corresponds to a SQLite witness row; its identifier distinguishes alternative explanations. Both queries include direct and package-linked classifications.

### Detailed Source replacement and evidence requests

D0 and D1 are compared using stable product–tariff keys. Additions and removals are identified first; route judgments and evidence-request categories are then compared for shared keys. Source records are aligned by domain identifiers before their fields are compared, so a changed file checksum alone does not constitute a change in the evidence state. The evidence-request state is a deterministic category comprising missing evidence, a conflict requiring inspection or supported context requiring no additional evidence under the rule.

The evidence-request rule first checks for a missing package link, then an exact-route conflict, then missing exact-route documentation and finally missing formulation wording. When none applies, the available context is retained. The formulation request denotes missing lexical evidence under the ancillary filter. The same precedence and source fields are applied to both source states (Supplement S4).

Three nested monitoring sets contain, respectively, membership changes; membership or judgment changes; and membership, judgment or evidence-request changes. Each set counts distinct product–tariff keys over the union of D0 and D1. For each key added by judgment or evidence-request monitoring, the before-and-after source records identify the changed field or package link.

Robustness checks perturb package identifiers, classifications and route fields, vary request priority and reconstruct cached answers after deletion, code change, route masking and duplication. Package linkage remains the first prerequisite in all offline graph-reference/SQL comparisons (Supplement S4).

### Detailed Execution measurements and transfer design

Tariff-review execution is compared at the level of a configuration: database engine, derivation strategy, query formulation, source state and execution interface. Neo4j and SQLite each calculate classification–tariff matches during the query or store them for reuse, giving four primary variants. All retain the same entities, source contents and supporting records. Stored matches take the form of Association–tariff relationships in Neo4j [74] or indexed rows in SQLite; the original linking record preserves each explanation for downstream queries (Appendix A.3).

Neo4j provides typed relationships and properties for the connected records [47], Cypher path queries and uniqueness constraints [48]. The ontology rules and SHACL checks use the separate RDF representation in Supplement S3. SQLite provides indexed joins and stored rows for the same local analytical tasks [67], with file-based operation requiring no separate database service [68].

Tariff measurements use Neo4j Community 5.26.1 and file-backed SQLite 3.45.1 on Linux/Python 3.12.3, with an Intel Xeon Silver 4416+ host reporting 80 logical CPUs and 1.08 TB physical RAM. Neo4j has a 1–2 GiB heap and 1 GiB page cache. Indexed, warm-cache retrieval includes complete local HTTP consumption; loading uses native deployment paths. Full configuration settings are specified in Supplement S4. The historical SQLite runs used default connection memory settings without a matched engine memory cap. Table A8 records this asymmetry; the historical timings are comparisons of deployed configurations, and equal answers do not isolate an engine-only effect.

Five tasks retrieve candidate links, source lineage, linking rules, combined classifications and same-tariff products with indication evidence; two further tasks inspect route fields and refreshed records. Task selection covers the required answer structures. Request frequencies are scenario inputs, not estimates from a production query log.

Each variant and dataset receives three warmups and fifteen timed repetitions in randomized, interleaved order. Both engines return results through local HTTP, with timing covering execution, transfer and consumption of all rows. Medians summarize latency. Checks outside the timed interval compare every output field, source-record identity and repeated-row count against the reference (Supplement S4).

Seven source-replacement cycles separately time loading, materialization, invalidation, replacement and reconstruction. Serial processing time is calculated as the sum of phase medians plus request counts multiplied by retrieval medians; query-time variants omit materialization, invalidation and reconstruction. Quartiles describe observed dispersion; paired bootstrap intervals describe within-deployment variation in the within-system break-even estimates (Supplement S4). For configuration c, request count Q, replacement count U and context fraction p, the two-query projection is C_c = B_c + U × R_c + Q × [p × T_context,c + (1 − p) × T_peer,c]. B_c includes the initial stored derivation where applicable; R_c includes invalidation and reconstruction where applicable. Each cost parameter is estimated from its measured phase or query samples. A sum of medians is not generally the median of an observed end-to-end workflow. The resulting totals cover serial database processing; reviewer time and economic cost are outside the calculation. They compare the tested deployment configurations, including their loading interfaces and memory settings. Unequal resource policies prevent attribution of the entire cost difference to the database engine alone (Table A8).

An exploratory analysis calculates an expanded grid of 600 scenarios varying replacement frequency, request count and the share of combined-context requests; remaining requests use the measured tariff peer/indication query. It retrieves same-tariff products with indication evidence, whereas classification-peer retrieval follows ATC ancestry. Four SQLite configurations combine automatic or ordered query formulations with query-time or stored derivation; two Neo4j configurations use query-time or stored derivation. The scenarios use the measured phase and query medians on the grid specified in Supplement S9. Request counts and task shares are planning assumptions; the resulting decision regions apply to this fixed-cost serial model. Initial loading is measured for D0 and control queries for D1; zero-replacement scenarios therefore use D0 loading as a proxy, and repeated replacements reuse the measured unit cost.

Sensitivity bounds are calculated by replacing every measured cost component with its first or third quartile and, in a separate analysis, by varying each component independently by ±10%. These deterministic bounds are not confidence or prediction intervals. A configuration is separated only when its upper cost is below every competitor's lower cost. Engine-level bounds take the minimum configuration costs within each engine at each bound, distinguishing an engine preference from an unresolved within-engine configuration choice (Supplement S9).

Exploratory execution controls isolate the effects of SQL join order and converging classification paths. For two complex tariff queries, automatic and fixed-order SQL [61] are interleaved with both Neo4j variants for fifteen repetitions. A separate exploratory three-product cycle query tests converging classification paths and shared source premises, using Neo4j HTTP and embedded SQLite with five repetitions. Supplement S4 specifies these protocols and the subsequent SQL-only plan control.

Classification-peer retrieval extends the design to entities sharing an ATC code or ancestor. Dictionary codes link to their immediately preceding recorded prefix. Traversal permits zero, two or four parent steps on each side of a shared ancestor. The membership census covers every entity with an admitted seven-character code: 5,678 Swiss authorizations in D1 and 3,647 ChEMBL molecule records. Source adapters preserve native entity identifiers and source rows; schema, queries and reference traversal remain unchanged between corpora. Both corpora use the same ATC hierarchy, so the transfer experiment tests a change in source structure within ATC-based retrieval.

Separate SQL source projections verify every witness, and Python prefix enumeration is compared with SQL closure queries for every entity. Source ablation removes Swiss package classifications or retains one lexically first ChEMBL code per molecule as an information-loss control.

The peer experiment uses PostgreSQL 16.13 alongside Neo4j and SQLite. PostgreSQL is configured with 1 GB shared buffers and 64 MB work memory; JIT and synchronous commit are enabled. Both SQL engines compare recursion over the full hierarchy with recursion starting from requested entities (anchors), preserving the same complete answers. Complete local HTTP transfer and decoding are timed; SQL uses a Python bridge and Neo4j its transactional endpoint. Indexes, subset sizes and further settings are specified in Supplement S4.

Native retrieval compares the three engines on nested hash-selected real-entity subsets targeting 10%, 40% and 100% of each corpus. Fourteen fixed anchors, one per first-level ATC group, are queried together as one batch. Two warmups precede nine interleaved repetitions per condition; Cypher and both SQL formulations return witnesses, source records, ancestors and depths. The 810 outputs are repeated batch measurements.

An exploratory workload census counts peers for every eligible entity and locates the fixed anchors within those distributions. Per-anchor explanation counts quantify batch concentration; the census does not supply additional latency measurements (Supplements S4–S5).

Additional reviewer-requested controls were specified before their new measurements and run in a separate Neo4j instance on the same SSH research host. SQLite was tested with default connection settings, a 1 GiB page-cache allowance, and that allowance plus a 1 GiB mmap region. Three blocks each contained three warmups and fifteen timed repetitions per task and derivation strategy, using fixed-order SQL and the same D1 context and tariff peer/indication answers. SQLite memory-arm order was randomized within blocks; Neo4j was measured in a separate sequence in each block. These sequences do not provide a fully randomized cross-engine comparison. Cache-capacity settings, file size and process memory were recorded without asserting equal total footprints. Seven randomized repetitions of all four engine/derivation arms directly timed a D0 build, D1 replacement and 100 context requests. Schema creation, reference construction and answer verification were excluded; SQLite ANALYZE and all retrieval consumption were included. Complete answers were rechecked after each cycle. The protocol, raw samples, execution plans and actual environment are provided in Supplement S10. These controls remain separate from the historical cost parameters.

Curation reversal, candidate aggregation and workload characterization were specified after the timing experiments and are exploratory. They reconstruct fixed source states and recorded answers without adding latency observations (Supplement S5).

Generative AI assisted structural critique, drafting, language editing, analysis-code work and automated consistency checks; the tools and author review are disclosed in the Acknowledgments. Supplement S8 documents ancillary documentary extraction and model-family checks.

