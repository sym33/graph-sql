# Supplement S11 Resource controlled comparison and cost decomposition

This follow-up addresses the fixed engine sequence, unequal external resource policies and combined aggregation interpretation in the initial controls. Its prespecified randomized resource protocol is separate from the retained initial measurements in S10. The cost decomposition reuses the saved 28 cycles and introduces no new lifecycle observations.

## Enforced resources and paired query procedure

Three user-owned services run the dedicated Neo4j instance and two SQLite workers on the designated SSH host. Each service has the same enforced memory.max of 4 or 8 GiB, memory.swap.max=0 and cpu.max=200000/100000 microseconds. All service process/thread affinities are verified as CPUs 20–21; the client runs on CPUs 22–23. No CPU exclusivity is claimed. The shared operating-system cache remains warm. Cgroup limits constrain the service allocation, not all shared host-cache accounting.

The first startup precheck found that the delegated cgroup hierarchy did not provide a cpuset controller. No timed response was collected in that attempt. Before measurements, the protocol was amended to use inherited taskset affinity and verify every member thread, retaining the failed precheck log. Memory and CPU quotas are checked from actual cgroup files before every block. Used memory is measured rather than padded to create equal RSS.

Neo4j Community 5.26.1 retains a 1–2 GiB heap and 1 GiB page cache. SQLite 3.45.1 compares default cache_size=-2000 with cache_size=-1048576 (1 GiB), without mmap. The same source snapshot, schema, indexes, queries and complete answer contract are retained. One controller times local HTTP request through decoding for both systems. Architecture-specific execution and serialization remain part of service latency; the comparison does not isolate engine-internal operator time.

Six blocks contain three repetitions of each memory budget in balanced shuffled order. Each block gives three warmups per condition, followed by fifteen repetitions in which all twelve engine/cache/task/derivation conditions are randomly interleaved. Both combined context and tariff-peer/indication tasks are included. Every timed answer is compared with the independent reference outside its timer. There are 1,080 complete responses, 24 budget-specific conditions and 45 observations per condition. Paired ratios align engine measurements by block/repetition; the repeated observations are not independent deployments.

Table 1. Randomized resource-controlled retrieval medians [Q1–Q3] in milliseconds. QT is query-time and S stored derivation.

| Budget GiB | Configuration | Strategy | Combined context | Tariff peers and indication |
| --- | --- | --- | --- | --- |
| 4 | SQLite default | QT | 37.55 [36.23–38.45] | 128.32 [126.17–129.88] |
| 4 | SQLite default | S | 40.13 [39.22–41.84] | 169.39 [167.26–172.51] |
| 4 | SQLite 1GiB | QT | 31.78 [30.54–33.11] | 116.84 [115.75–120.21] |
| 4 | SQLite 1GiB | S | 35.19 [33.98–36.55] | 149.30 [146.88–151.42] |
| 4 | Neo4j 1GiB | QT | 154.73 [151.36–158.90] | 1145.42 [1137.04–1153.16] |
| 4 | Neo4j 1GiB | S | 38.63 [37.57–40.35] | 699.68 [690.74–708.57] |
| 8 | SQLite default | QT | 36.91 [36.02–38.47] | 127.88 [126.79–129.11] |
| 8 | SQLite default | S | 40.24 [39.23–41.29] | 171.32 [168.45–175.58] |
| 8 | SQLite 1GiB | QT | 32.29 [31.05–33.65] | 117.42 [116.00–119.32] |
| 8 | SQLite 1GiB | S | 34.88 [33.44–35.74] | 148.84 [147.25–152.44] |
| 8 | Neo4j 1GiB | QT | 153.96 [149.15–157.72] | 1156.31 [1142.09–1168.40] |
| 8 | Neo4j 1GiB | S | 39.58 [37.20–41.21] | 702.03 [692.14–725.07] |

Table 2. Service cgroup memory.current ranges after the three blocks at each budget, in MiB. These include charged service memory/file-cache accounting and are not engine-only RSS. Peak values are cumulative across the service lifetime and are retained only in raw records.

| Budget GiB | Service | Current memory range MiB | OOM events |
| --- | --- | --- | --- |
| 4 | Neo4j | 1782.8–1785.6 | 0 |
| 4 | SQLite default | 19.3–19.4 | 0 |
| 4 | SQLite 1 GiB cache | 35.4–35.5 | 0 |
| 8 | Neo4j | 1783.4–1785.2 | 0 |
| 8 | SQLite default | 19.3–19.4 | 0 |
| 8 | SQLite 1 GiB cache | 35.4–35.4 | 0 |

All 1,080 responses preserve the complete reference outputs. In the stored-context comparison at 4 GiB, default SQLite has a 40.13 ms median versus 38.63 ms for Neo4j; allowing a 1 GiB SQLite cache lowers its median to 35.19 ms. The same median-order reversal occurs at 8 GiB. These are descriptive condition medians, not confidence claims. The result provides a measured direction for these tasks under equal ceilings without asserting that tuning closes or widens every database gap. Neither ceiling generated an OOM event; the results do not establish performance under a memory-exhausted workload.

## Exact separation of aggregation effects

For cycle i, let P_i be the sum of measured upkeep/loading phases, B_i the sum of its 100 measured request times, and T_i the outer elapsed time. Let med denote the median, P=sum over phases of their medians, and Q=100 × med of all pooled individual request times. The original projection is P+Q. Its signed difference from med(T_i) has four additive components:

1. Individual-phase aggregation: P − med(P_i).
2. Combining phase/query blocks: med(P_i)+med(B_i) − med(P_i+B_i).
3. Single-request extrapolation: Q − med(B_i).
4. Timer residual: med(P_i+B_i) − med(T_i).

Their sum equals P+Q−med(T_i) exactly. Components are signed accounting terms; cancellation is possible and they are not independent causal effects. The block-based alternative P+med(B_i) removes the single-request extrapolation term but changes the estimator; it does not create new observations.

Table 3. Signed components as percentage points of the observed outer median. Columns sum to the original relative projection error.

| Engine and strategy | Individual phases | Combining blocks | Single request extrapolation | Timer residual | Total |
| --- | --- | --- | --- | --- | --- |
| SQLite QT | +0.15 | +1.04 | +3.19 | -0.06 | +4.31 |
| SQLite S | -0.32 | -1.27 | -10.78 | -0.08 | -12.46 |
| Neo4j QT | -0.15 | -1.39 | -11.47 | -0.00 | -13.01 |
| Neo4j S | -0.13 | +5.64 | -13.30 | -0.00 | -7.79 |

The individual-phase term ranges from −0.32 to +0.15 percentage points. The largest −13.01% total error (query-time Neo4j) is dominated by −11.47 points from extrapolating a pooled single-request median. The block-based projection errors are +1.12% for query-time SQLite, −1.67% for stored SQLite, −1.54% for query-time Neo4j and +5.51% for stored Neo4j. This corrects attributing the whole −13.01% to summing phase medians.

## Historical projection and new session reconciliation

The historical model uses warmed interleaved retrieval medians; the new 28 outer totals include immediate post-replacement request bursts. The accounting bridge first changes each historical measured component to the corresponding new-session component, then adds the new projection/observed-total gap. ANALYZE is an explicit additional component in the new SQLite boundary. This reconciles every difference exactly without assigning an unmeasured historical host-load, cache or JIT cause.

Table 4. Historical/new-session reconciliation in seconds. Base loading combines initial and replacement phases; stored upkeep combines materialization, invalidation and reconstruction. Changes sum to the observed total difference.

| Engine and strategy | Historical projection | Base loading change | Stored upkeep and ANALYZE change | Query projection change | New projection to observed gap | New observed total |
| --- | --- | --- | --- | --- | --- | --- |
| SQLite QT | 5.30 | -0.15 | +0.02 | +1.93 | -0.29 | 6.80 |
| SQLite S | 5.69 | -0.16 | +0.01 | -0.12 | +0.77 | 6.19 |
| Neo4j QT | 29.89 | +1.53 | +0.00 | +1.46 | +4.92 | 37.80 |
| Neo4j S | 17.19 | +1.66 | -0.05 | +11.16 | +2.53 | 32.50 |

For stored Neo4j, 11.16 s of the 15.31 s historical/new difference is associated with changing the context-query median parameter, 1.66 s with base loading, −0.05 s with stored-link upkeep and 2.53 s with the remaining aggregation/outer-total gap. The initial repeated burst runs vary in request latency even late in their blocks; no single warmup explanation is inferred from those observations alone. Historic deployment causes cannot be uniquely reconstructed from missing historical telemetry.


## Controlled post replacement warmup contrast

A separate protocol, specified before its measurements, tests zero versus thirty untimed context requests after full D1 replacement and rematerialization in the same resource-controlled Neo4j service. Three pairs randomize the condition order at a 4 GiB ceiling, no swap and the same CPU quota/affinity. Each arm measures a 100-request block, retaining and checking every response after timing. All 600 answers match the complete reference.

Table 5. Observed 100-request block times in seconds, paired within session. A positive difference means the thirty-warmup condition is faster.

| Pair | No warmup | Thirty warmups | Paired difference |
| --- | --- | --- | --- |
| 1 | 4.068 | 4.131 | -0.063 |
| 2 | 17.108 | 3.654 | +13.454 |
| 3 | 3.778 | 3.720 | +0.058 |

Two pairs show similar block times with either warmup policy; one no-warmup block is much slower. The contrast demonstrates session-level variability and a possible state interaction, but the three pairs do not establish a stable warming effect or uniquely explain historical deployment causes. All observations, including the near-null pair differences, are retained. The main historical/new-session reconciliation remains an exact accounting identity rather than a causal attribution.

## Reproduction

Followup_Controls.zip contains the prespecified resource and warmup protocols, executed code, raw paired observations, actual cgroup records, failed precheck log, exact decomposition and independent verification. Run python3 code/verify_followup.py to verify the saved results without starting database services. The frozen source identities and original comparison/reference dependencies accompany the base archive and Reviewer_Controls.zip. Native scripts document the dedicated installation paths and loopback endpoints; adapting those paths is necessary on another host.
