# Supplement S2. Identity policies and reference coverage

## Identity definition

External-reference access is evaluated separately from classification compatibility. Authorization-linked Refdata active-ingredient IDs supply source-specific substance declarations. Exact preferred-name or synonym matches require agreement on one ChEMBL parent and never use the asserted ATC to choose identity.

An exploratory lexical policy generates candidate forms from Latin names of at most four tokens: a terminal um may remain unchanged, be removed or be replaced by e. Every candidate must exactly match a reference name or synonym, and all matched parents must agree. Newly resolved SL fields also undergo a product-specific check requiring an intersecting Refdata substance ID for the same authorization.

## Coverage and granularity boundaries

Table S2. External coverage under progressively explicit identity obligations.

| Policy on D0 SL | Resolved reference rows | Exact external support | Residual boundary |
| --- | --- | --- | --- |
| Unchanged exact-name comparator | 545 | 517 | 9,720 unresolved; 28 discordant |
| Exact official synonym lookup | 545 | 517 | No additional reference names resolve |
| Exploratory lexical candidates | 5,979 | 5,946 | 4,286 unresolved; 30 discordant; 3 temporal |
| New identities additionally require source-ID concordance | 5,907 | 5,874 | 72 new identities withheld; remaining classifications as above |

Lexical expansion adds 5,434 resolved package rows, representing 1,790 authorization–substance fields. Source-ID checking supports 5,362 of these rows and withholds 72 across ten fields. The withheld cases include contrast agents declared as iodine, tenofovir-disoproxil products declared as tenofovir, and silymarin declared as a plant extract. They expose differences in declaration granularity. Coverage rises from 5.31% to 58.25% under lexical expansion, or 57.55% after the additional source-ID gate. These are policy-specific identity-access rates. Parent agreement and source-ID intersection establish the stated documentary conditions; product-level chemical equivalence requires further evidence. Complete candidate records and source crosschecks remain in the experiment package.
